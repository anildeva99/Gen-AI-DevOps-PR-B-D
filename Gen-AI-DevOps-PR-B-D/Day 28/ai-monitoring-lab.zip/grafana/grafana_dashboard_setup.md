# Grafana Dashboard Setup
1. Open Grafana → Configuration → Data Sources → Add Prometheus.
2. Set Prometheus URL to: `http://<monitoring-vm-internal-ip>:9090`
3. Save & Test connection.
4. Import `ai_insights_dashboard.json`.
5. Create panels for metrics:
   - `ai_insights_cpu_usage_percent`
   - `ai_insights_memory_usage_percent`
   - `ai_insights_anomalies_total`
   - `ai_insights_summary`
6. (Optional) Add alert rules in Prometheus for AI anomalies.
