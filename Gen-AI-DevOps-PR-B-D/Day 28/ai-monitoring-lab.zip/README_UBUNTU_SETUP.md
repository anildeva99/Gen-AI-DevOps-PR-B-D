# AI Monitoring Lab (Prometheus + Grafana + AI Anomaly Insights)

## Monitoring VM Setup
1. Run `setup_monitoring_vm.sh`.
2. Verify Prometheus UI: http://<vm-ip>:9090/targets
3. Verify metrics endpoint: http://<vm-ip>:9105/

## Target VM Setup
1. Run `node_exporter_setup.sh`.
2. Check metrics at http://<target-vm-ip>:9100/metrics

## Grafana Setup
1. Import `ai_insights_dashboard.json`.
2. Configure Prometheus datasource → use Monitoring VM internal IP.

## Alerts
Define `ai_alert_rules.yml` in Prometheus for anomaly conditions (CPU, memory, AI summary).
