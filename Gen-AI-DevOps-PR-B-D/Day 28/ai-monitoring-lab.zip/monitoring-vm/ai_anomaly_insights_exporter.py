from prometheus_client import Gauge, start_http_server
import random, time

ai_summary = Gauge('ai_insights_summary', 'AI-generated anomaly summary (0=normal,1=moderate,2=critical)')

def generate_summary():
    while True:
        summary_level = random.choice([0, 1, 2])
        ai_summary.set(summary_level)
        print("🧠 AI Summary:", "Normal" if summary_level == 0 else "Moderate anomalies detected." if summary_level == 1 else "Critical anomalies detected!")
        time.sleep(10)

if __name__ == "__main__":
    PORT = 9105
    print(f"🚀 Starting AI Insights exporter with summary on port {PORT}")
    start_http_server(PORT)
    generate_summary()
