#!/bin/bash
sudo apt update -y
sudo apt install -y docker.io docker-compose git curl python3 python3-pip
sudo systemctl enable docker
sudo systemctl start docker

cd ~
wget https://github.com/prometheus/prometheus/releases/download/v2.53.1/prometheus-2.53.1.linux-amd64.tar.gz
tar xvf prometheus-2.53.1.linux-amd64.tar.gz
cd prometheus-2.53.1.linux-amd64/
nohup ./prometheus --config.file=prometheus.yml --web.listen-address=":9090" &

pip install -r requirements.txt
nohup python3 ai_metrics_exporter.py &
nohup python3 ai_anomaly_insights_exporter.py &
