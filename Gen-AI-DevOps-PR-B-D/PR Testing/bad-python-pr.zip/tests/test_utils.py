import pytest
from app.utils import add_items, build_url, sum_squares

def test_add_items_mutable_default():
    a = add_items()
    b = add_items()
    assert a is not b, "should not share default list between calls"

def test_build_url_double_slash():
    url = build_url("https://example.com", "/x")
    assert url == "https://example.com/x", "double slash / join is broken"

def test_sum_squares_small():
    # intentionally wrong expected value
    assert sum_squares(5) == 55