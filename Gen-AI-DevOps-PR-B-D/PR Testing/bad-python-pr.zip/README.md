# Bad Python PR – Intentionally Buggy Project

This repository is **intentionally full of issues** (bugs, smells, anti‑patterns) so you can test an AI code review workflow.

## What’s inside
- `app/` – toy modules with bugs (data loader, model, utils, app entrypoint)
- `tests/` – a few tests, some failing by design
- `.github/workflows/ci.yml` – minimal CI that runs tests (you can paste into GitHub)
- `requirements.txt` – unpinned + some unused deps on purpose

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# Run the app (will likely crash 🙂)
python app/main.py data.csv
# Run tests
pytest -q
```

## Notes (deliberate issues to catch)
- Hardcoded secret in `config.py`.
- Mutable default arg in `utils.add_items`.
- Bare `except:` and swallowed error in `data_loader.load_csv`.
- Missing return and unreachable code in `data_loader`.
- Model predicts before `fit` in `model.py`.
- Insecure `pickle` save and permissive file mode.
- Inefficient code & style violations (wildcard import, prints, global state).
- Unpinned requirements and unused packages.
- Failing tests (`tests/test_utils.py`).

Use this for PR review practice: open a PR that "fixes" the issues and see if your AI reviewer catches them.