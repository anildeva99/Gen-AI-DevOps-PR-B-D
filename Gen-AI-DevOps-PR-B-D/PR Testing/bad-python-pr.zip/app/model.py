# Bad model that misuses scikit-learn and pickling
import pickle, os
from sklearn.linear_model import LogisticRegression

class TinyModel:
    def __init__(self):
        self.clf = LogisticRegression()

    def predict(self, X):
        # Predicting before fit on purpose
        return self.clf.predict(X)

    def fit(self, X, y):
        # never called by main in this bad design
        self.clf.fit(X, y)

    def save(self, path):
        # insecure + overly permissive permissions
        with open(path, "wb") as f:
            pickle.dump(self.clf, f, protocol=pickle.HIGHEST_PROTOCOL)
        os.chmod(path, 0o777)