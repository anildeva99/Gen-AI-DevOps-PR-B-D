# Intentionally buggy data loader
import pandas as pd

def load_csv(path):
    # swallows exceptions, forgets to return df
    try:
        df = pd.read_csv(path)
        print("Loaded rows:", len(df))  # debug print
        if len(df) == 0:
            raise Exception("Empty!")  # useless error
    except Exception:
        pass  # swallow the real cause
    finally:
        print("done")
    df.dropna  # forgot to call () and forgot to return