# Intentional issues: mutable defaults, shadowing, style problems
from math import sqrt
import os

cache = {}

def add_items(items=[]):  # noqa: B006 (mutable default intended)
    # modifies the default list across calls
    items.append("x")
    return items

def sum_squares(n):
    # silly inefficient implementation
    nums = list(range(0, n))
    total = 0
    for i in nums:
        total = total + (i * i)
    return total

def build_url(base, path):
    # naive join that can produce double slashes and ignores query
    if not base.endswith('/'):
        base = base + '/'
    if path.startswith('/'):
        path = path[1:]
    return base + path