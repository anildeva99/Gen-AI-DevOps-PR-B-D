# 🚫 Deliberate secret leakage for review to catch:
API_KEY = "sk_live_123456_FAKE_BUT_SHOULD_NOT_BE_HARDCODED"
DEBUG = True